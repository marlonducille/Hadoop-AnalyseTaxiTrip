
-- -----------------------------------------------------
-- Author: Andalib Ansari, Udemy
-- -----------------------------------------------------

-- -----------------------------------------------------
-- For Big Data and Hadoop for Beginners - with Hands-on!
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Table `dwh_test`.`dim_time`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `dwh_test`.`dim_time` (
  `time_key` INT(2) NOT NULL,
  `hour` VARCHAR(5) NULL DEFAULT NULL,
  `business_time` VARCHAR(50) NULL DEFAULT NULL,
  PRIMARY KEY (`time_key`))
  ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

--loading the dimension table. this will be a one time load 
insert into `dwh_test`.`dim_time` (time_key,hour,business_time) 
values
(0,'12am','Late Night'),
(1,'1am','Late Night'),
(2,'2am','Late Night'),
(3,'3am','Early Morning'),
(4,'4am','Early Morning'),
(5,'5am','Early Morning'),
(6,'6am','Early Morning'),
(7,'7am','AM Peak'),
(8,'8am','AM Peak'),
(9,'9am','AM Peak'),
(10,'10am','Mid Morning'),
(11,'11am','Mid Morning'),
(12,'12pm','Lunch'),
(13,'1pm','Lunch'),
(14,'2pm','Mid Afternoon'),
(15,'3pm','Mid Afternoon'),
(16,'4pm','Mid Afternoon'),
(17,'5pm','Evening'),
(18,'6pm','Evening'),
(19,'7pm','PM Peak'),
(20,'8pm','PM Peak'),
(21,'9pm','PM Peak'),
(22,'10pm','Night'),
(23,'11pm','Night');

---

-- -----------------------------------------------------
-- Table `dwh_test`.`dim_date`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dwh_test`.`dim_date` (
  `date_key` INT(8) NOT NULL,
  `date` DATETIME NULL DEFAULT NULL,
  `date_short` TINYTEXT NULL DEFAULT NULL,
  `date_medium` TINYTEXT NULL DEFAULT NULL,
  `date_long` TINYTEXT NULL DEFAULT NULL,
  `date_full` TINYTEXT NULL DEFAULT NULL,
  `day_in_year` TINYTEXT NULL DEFAULT NULL,
  `day_name` TINYTEXT NULL DEFAULT NULL,
  `day_abbreviation` TINYTEXT NULL DEFAULT NULL,
  `month_abbreviation` TINYTEXT NULL DEFAULT NULL,
  `month_name` TINYTEXT NULL DEFAULT NULL,
  `quarter_name` TINYTEXT NULL DEFAULT NULL,
  `year_quarter` TINYTEXT NULL DEFAULT NULL,
  `year_month_abbreviation` TINYTEXT NULL DEFAULT NULL,
  `is_last_day_in_month` TINYTEXT NULL DEFAULT NULL,
  `is_first_day_in_month` TINYTEXT NULL DEFAULT NULL,
  `year2` TINYTEXT NULL DEFAULT NULL,
  `year4` TINYTEXT NULL DEFAULT NULL,
  `day_in_month` TINYTEXT NULL DEFAULT NULL,
  `week_in_year` TINYTEXT NULL DEFAULT NULL,
  `week_in_month` TINYTEXT NULL DEFAULT NULL,
  `month_number` TINYTEXT NULL DEFAULT NULL,
  `quarter_number` TINYTEXT NULL DEFAULT NULL,
  `year_month_number` TINYTEXT NULL DEFAULT NULL,
  `is_last_day_in_week` TINYTEXT NULL DEFAULT NULL,
  `is_first_day_in_week` TINYTEXT NULL DEFAULT NULL,
  `load_time` DATETIME NULL DEFAULT NULL,
   PRIMARY KEY (`date_key`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

-- -----------------------------------------------------
-- Table `dwh_test`.`dim_vendors` 
-- -----------------------------------------------------

--Dimension Type: SCD Type2

CREATE TABLE IF NOT EXISTS `dwh_test`.`dim_vendors` (
  `vid_sk` INT(10) NOT NULL,
  `vendor_id` INT(10) NULL DEFAULT NULL,
  `vendor_name` VARCHAR(250) NULL DEFAULT NULL,
  `status_code` VARCHAR(250) NULL DEFAULT NULL,
  `version` INT(11) NULL DEFAULT NULL,
  `date_from` DATETIME NULL DEFAULT NULL,
  `date_to` DATETIME NULL DEFAULT NULL,
  `load_time` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`vid_sk`))
  ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `dwh_test`.`trip_pickup_facts`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dwh_test`.`trip_pickup_facts` (
  `fact_id` INT(11) NOT NULL AUTO_INCREMENT,
  `vid_sk` INT(10) NULL DEFAULT NULL,
  `date_key` INT(8) NULL DEFAULT NULL,
  `time_key` INT(2) NULL DEFAULT NULL,
  `pickup_time` DATETIME NULL DEFAULT NULL,
  `payment_type` FLOAT(8,2) NULL DEFAULT NULL,
  `fare_amount` FLOAT(8,2) NULL DEFAULT NULL,
  `extra` FLOAT(8,2) NULL DEFAULT NULL,
  `mta_tax` FLOAT(8,2) NULL DEFAULT NULL,
  `tip_amount` FLOAT(8,2) NULL DEFAULT NULL,
  `tolls_amount` FLOAT(8,2) NULL DEFAULT NULL,
  `improvement_surcharge` FLOAT(8,2) NULL DEFAULT NULL,
  `total_amount` FLOAT(8,2) NULL DEFAULT NULL,
  `load_date` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`fact_id`),
  INDEX `vid_sk_idx` (`vid_sk` ASC),
  INDEX `date_key_idx` (`date_key` ASC),
  INDEX `time_key_idx` (`time_key` ASC),
  CONSTRAINT `vid_sk_cns`
    FOREIGN KEY (`vid_sk`)
    REFERENCES `dwh_test`.`dim_vendors` (`vid_sk`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `date_key_cns`
    FOREIGN KEY (`date_key`)
    REFERENCES `dwh_test`.`dim_date` (`date_key`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `time_key_cns`
    FOREIGN KEY (`time_key`)
    REFERENCES `dwh_test`.`dim_time` (`time_key`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


